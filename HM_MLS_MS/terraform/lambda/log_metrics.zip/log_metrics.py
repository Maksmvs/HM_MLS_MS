def lambda_handler(event, context):
    print("Logging metrics...")
    return {"status": "logged"}
