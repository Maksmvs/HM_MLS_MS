def lambda_handler(event, context):
    print("Validating data...")
    return {"status": "validated"}
